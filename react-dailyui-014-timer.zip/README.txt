A Pen created at CodePen.io. You can find this one at https://codepen.io/jackoliver/pen/vXYpRN.

 Day 14 of 100 - A sweet little timer. Look out for a funny little music reference too. :P

Peace! See ya tomorrow.